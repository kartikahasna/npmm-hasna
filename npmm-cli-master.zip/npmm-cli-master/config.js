module.exports = {
  API_ENDPOINT: 'https://npmm-server-production.up.railway.app',
};
